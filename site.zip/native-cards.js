/* 《凝顾》卡牌只读适配验证。不会写回磁盘，也不会更改 GCS 演示项目。 */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const dialog = $('native-card-dialog');
  const fileField = $('native-card-file');
  const content = $('native-card-content');
  const fileStatus = $('native-file-status');
  const MAX_FILE_SIZE = 8 * 1024 * 1024;
  let records = [];
  let selectedIndex = 0;
  let searchText = '';
  function el(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = String(text);
    if (className) node.className = className;
    return node;
  }
  function cardName(record) {
    for (const key of ['name', 'display_name', 'title', 'card_name', '名称']) {
      if (typeof record.value[key] === 'string' && record.value[key].trim()) return record.value[key];
    }
    return record.id;
  }
  function readRecords(json) {
    if (!json || typeof json !== 'object' || Array.isArray(json) || !Object.hasOwn(json, 'cards')) {
      throw new Error('根对象应包含 cards 字段（《凝顾》basic_cards.json 的结构）。');
    }
    const source = json.cards;
    let arr;
    if (Array.isArray(source)) arr = source.map((v, index) => ({key: String(index), value: v}));
    else if (source && typeof source === 'object') arr = Object.entries(source).map(([key, value]) => ({key, value}));
    else throw new Error('cards 应为数组或以卡牌 ID 为键的对象。');
    if (arr.length > 10000) throw new Error('卡牌数量超过只读查看器的安全上限。');
    arr.forEach((record, index) => {
      if (!record.value || typeof record.value !== 'object' || Array.isArray(record.value)) throw new Error('第 ' + (index + 1) + ' 条卡牌不是对象。');
      const id = ['id', 'card_id'].map(key => record.value[key]).find(x => typeof x === 'string' && x.trim());
      record.id = id || record.key;
    });
    const ids = new Set();
    for (const record of arr) {
      if (ids.has(record.id)) throw new Error('卡牌 ID 重复：' + record.id);
      ids.add(record.id);
    }
    return arr;
  }
  function renderDetails(record, right) {
    right.append(el('h3', cardName(record)));
    right.append(el('p', 'ID：' + record.id, 'native-subtitle'));
    const table = el('table', undefined, 'native-fields');
    const rows = Object.entries(record.value);
    for (const [key, value] of rows) {
      const tr = document.createElement('tr');
      tr.append(el('th', key));
      const valueNode = el('td');
      const str = value === null ? 'null' : typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value);
      valueNode.append(el('pre', str));
      tr.append(valueNode);
      table.append(tr);
    }
    right.append(table);
    const details = el('details');
    details.append(el('summary', '展开完整原始 JSON'));
    details.append(el('pre', JSON.stringify(record.value, null, 2), 'native-json'));
    right.append(details);
  }
  function render() {
    content.replaceChildren();
    if (!records.length) { content.append(el('p', '文件没有卡牌记录。', 'native-empty')); return; }
    const layout = el('div', undefined, 'native-layout');
    const left = el('div', undefined, 'native-list');
    const search = document.createElement('input');
    search.type = 'search';
    search.placeholder = '按名称或 ID 搜索卡牌';
    search.setAttribute('aria-label', '搜索真实卡牌');
    search.value = searchText;
    search.addEventListener('input', () => { searchText = search.value; renderList(); });
    const listing = el('div');
    function renderList() {
      listing.replaceChildren();
      const found = records.map((r,i) => ({r,i})).filter(({r}) => (cardName(r)+' '+r.id).toLowerCase().includes(searchText.trim().toLowerCase()));
      leftCount.textContent = '匹配 ' + found.length + ' / ' + records.length;
      for (const {r,i} of found) {
        const b = el('button', cardName(r) + ' · ' + r.id, 'native-record' + (i === selectedIndex ? ' active' : ''));
        b.addEventListener('click', () => { selectedIndex = i; renderDetailsSelected(); renderList(); });
        listing.append(b);
      }
    }
    const leftCount = el('p', '', 'native-subtitle');
    left.append(search,leftCount,listing);
    const right = el('section',undefined,'native-detail');
    function renderDetailsSelected() { right.replaceChildren();renderDetails(records[selectedIndex],right); }
    renderDetailsSelected();renderList();layout.append(left,right);content.append(layout);
  }
  $('native-card-btn').addEventListener('click', () => dialog.showModal());
  $('native-close').addEventListener('click', () => dialog.close());
  fileField.addEventListener('change', async () => {
    const file = fileField.files && fileField.files[0];
    if (!file) return;
    if (file.size > MAX_FILE_SIZE) {fileStatus.textContent = '文件超过 8MB，未读取';return;}
    try {
      const parsed = JSON.parse(await file.text());
      const nextRecords = readRecords(parsed);
      records = nextRecords;
      selectedIndex = 0;
      searchText = '';
      fileStatus.textContent = '已读取：' + file.name + ' · ' + records.length + ' 条卡牌；仅内存查看';
      render();
    } catch (error) {
      fileStatus.textContent = '读取失败：' + error.message + '（原显示内容不变）';
    }
  });
  // 暴露给独立测试：没有写入接口，也不加载 GCS 原型的卡牌字段规范。
  window.GCSNativeCardReader = {readRecords,cardName};
})();
