# Game Content Studio (GCS) · Website prototype 0.2

这是一个可直接通过 GitHub Pages 发布的静态网页版本；不需要服务器、数据库或 Node.js 构建。

## 当前功能

- NPC、剧情、卡牌演示数据的编辑、关联与浏览
- 演示项目 JSON 导出 / 导入，浏览器本地自动暂存
- 现有《凝顾》卡牌 `data/cards/basic_cards.json` 只读查看（在页面中手动选择本地文件）

## 数据边界

- 发布的 GitHub 仓库只应包含此目录下的网页源文件；**不要上传游戏源码、真实游戏数据、未公开美术、存档或 API 密钥**。
- 网站访问者可以查看公开仓库中的网页代码。演示数据内置在 `model.js` 中，也会对外公开。
- 选择本地 JSON 后，页面使用浏览器 `File.text()` 读取，无网络上传接口。
- 编辑的演示工作区暂存于当前浏览器的 `localStorage`。这不是远程同步，也不替代文件备份。
- 「保存 JSON」会导出一个本地下载文件；不会自动更改游戏项目。
- 更换域名或从 `file://` 切换到 HTTPS 后，原本地暂存不会自动迁移；提前在旧版本导出 JSON，再在新网站导入。

## 手动首次发布（一次性）

1. 在 GitHub 创建一个**全新、公开**仓库，例如 `gcs`；不使用现有游戏仓库。
2. 把本目录的 `index.html`、`app.js`、`model.js`、`native-cards.js`、`styles.css`、`assets/`、`.nojekyll`、`README.md` 上传到新仓库根目录，并提交至 `main`。
3. 打开该仓库 **Settings → Pages → Build and deployment → Deploy from a branch**，选择 `main` 和 `/ (root)`，保存。
4. 等待 GitHub 页面显示网站网址（通常形如 `https://<username>.github.io/<repository>/`）。

以后只需要更新这个仓库的文件，GitHub Pages 会重新发布。刷新网址即可。

如果使用 ChatGPT 已连接的 GitHub 访问权限，可以在创建仓库之后让助手将这些网页源文件直接提交到新仓库；不必自己反复上传 ZIP。
